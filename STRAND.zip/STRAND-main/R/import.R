#' @importFrom stats complete.cases median model.matrix rbeta rbinom rnorm rpois sd pnorm
#' @importFrom grDevices terrain.colors
#' @importFrom graphics pairs
NULL

